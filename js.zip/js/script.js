// Main JavaScript for Beyond the Book Website

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const menu = document.getElementById('menu');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            menu.classList.toggle('active');
        });
    }
    
    // Contact Form Submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }
    
    // Registration System
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        // Check session availability on page load
        checkSessionAvailability();
        
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get selected session
            const sessionOption = document.querySelector('input[name="session_option"]:checked');
            if (!sessionOption) {
                alert('Please select a session option.');
                return;
            }
            
            // Validate form
            const requiredFields = registrationForm.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                } else {
                    field.classList.remove('error');
                }
            });
            
            if (!isValid) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Simulate form submission
            const formData = new FormData(registrationForm);
            const sessionValue = sessionOption.value;
            
            // Update session count in localStorage
            updateSessionCount(sessionValue);
            
            // Store registration data
            saveRegistration(formData);
            
            // Show success message
            alert('Thank you for registering! Your registration has been received.');
            registrationForm.reset();
            
            // Update availability display
            checkSessionAvailability();
        });
    }
});

// Function to check session availability
function checkSessionAvailability() {
    const tueThuOption = document.getElementById('session_tue_thu');
    const monWedOption = document.getElementById('session_mon_wed');
    
    if (!tueThuOption || !monWedOption) return;
    
    const tueThuCount = getSessionCount('tue_thu');
    const monWedCount = getSessionCount('mon_wed');
    
    const tueThuAvail = document.getElementById('tue_thu_availability');
    const monWedAvail = document.getElementById('mon_wed_availability');
    
    // Update Tuesday/Thursday availability
    if (tueThuCount >= 5) {
        tueThuOption.disabled = true;
        if (tueThuAvail) {
            tueThuAvail.textContent = 'FULL';
            tueThuAvail.classList.add('session-full');
        }
    } else {
        tueThuOption.disabled = false;
        if (tueThuAvail) {
            tueThuAvail.textContent = `${5 - tueThuCount} spots left`;
            tueThuAvail.classList.remove('session-full');
        }
    }
    
    // Update Monday/Wednesday availability
    if (monWedCount >= 5) {
        monWedOption.disabled = true;
        if (monWedAvail) {
            monWedAvail.textContent = 'FULL';
            monWedAvail.classList.add('session-full');
        }
    } else {
        monWedOption.disabled = false;
        if (monWedAvail) {
            monWedAvail.textContent = `${5 - monWedCount} spots left`;
            monWedAvail.classList.remove('session-full');
        }
    }
}

// Function to get current session count
function getSessionCount(sessionType) {
    const count = localStorage.getItem(`${sessionType}_count`);
    return count ? parseInt(count) : 0;
}

// Function to update session count
function updateSessionCount(sessionType) {
    const currentCount = getSessionCount(sessionType);
    localStorage.setItem(`${sessionType}_count`, currentCount + 1);
}

// Function to save registration data
function saveRegistration(formData) {
    // Convert FormData to object
    const registrationData = {};
    formData.forEach((value, key) => {
        registrationData[key] = value;
    });
    
    // Add timestamp
    registrationData.timestamp = new Date().toISOString();
    
    // Get existing registrations
    let registrations = JSON.parse(localStorage.getItem('registrations') || '[]');
    
    // Add new registration
    registrations.push(registrationData);
    
    // Save back to localStorage
    localStorage.setItem('registrations', JSON.stringify(registrations));
}

// Admin Dashboard Functions
function loadRegistrations() {
    const registrationsTable = document.getElementById('registrationsTable');
    if (!registrationsTable) return;
    
    const registrations = JSON.parse(localStorage.getItem('registrations') || '[]');
    const tableBody = registrationsTable.querySelector('tbody');
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    if (registrations.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="7" class="text-center">No registrations yet</td>';
        tableBody.appendChild(row);
        return;
    }
    
    // Add registrations to table
    registrations.forEach((reg, index) => {
        const row = document.createElement('tr');
        
        const sessionText = reg.session_option === 'tue_thu' ? 
            'Tuesday/Thursday 8:30-9:30 AM CEST' : 
            'Monday/Wednesday 7:00-8:00 PM CEST';
        
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${reg.student_name || 'N/A'}</td>
            <td>${reg.student_age || 'N/A'}</td>
            <td>${reg.parent_name || 'N/A'}</td>
            <td>${reg.parent_email || 'N/A'}</td>
            <td>${sessionText}</td>
            <td>${new Date(reg.timestamp).toLocaleString()}</td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Admin Login
function adminLogin() {
    const loginForm = document.getElementById('adminLoginForm');
    if (!loginForm) return;
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        // Simple authentication (in production, this would be server-side)
        if (username === 'admin' && password === 'beyondthebook2025') {
            // Store login state
            sessionStorage.setItem('adminLoggedIn', 'true');
            // Redirect to dashboard
            window.location.href = 'dashboard.html';
        } else {
            alert('Invalid username or password');
        }
    });
}

// Check admin authentication
function checkAdminAuth() {
    const isLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';
    const isLoginPage = window.location.href.includes('login.html');
    const isDashboardPage = window.location.href.includes('dashboard.html');
    
    if (!isLoggedIn && isDashboardPage) {
        // Redirect to login if not authenticated
        window.location.href = 'login.html';
    } else if (isLoggedIn && isLoginPage) {
        // Redirect to dashboard if already logged in
        window.location.href = 'dashboard.html';
    }
    
    // Load registrations if on dashboard
    if (isLoggedIn && isDashboardPage) {
        loadRegistrations();
        
        // Add logout functionality
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                sessionStorage.removeItem('adminLoggedIn');
                window.location.href = 'login.html';
            });
        }
    }
}

// Initialize admin functions
function initAdmin() {
    adminLogin();
    checkAdminAuth();
}

// Call admin initialization
initAdmin();
